from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import json
from datetime import datetime
import random
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///quiz.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    quizzes = db.relationship('QuizResult', backref='user', lazy=True)

class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)
    question_text = db.Column(db.String(200), nullable=False)
    correct_answer = db.Column(db.String(100), nullable=False)
    choices = db.Column(db.String(500), nullable=False)  # JSON list of choices

class QuizResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    date_taken = db.Column(db.DateTime, default=datetime.utcnow)

def get_feedback(score):
    if score >= 90:
        return "عالی! شما عملکرد فوق‌العاده‌ای داشتید!"
    elif score >= 75:
        return "خیلی خوب! شما تسلط خوبی دارید."
    elif score >= 50:
        return "قابل قبول، اما جای پیشرفت دارید."
    else:
        return "نیاز به تمرین بیشتری دارید. تلاش کنید!"

@app.route('/submit_quiz', methods=['POST'])
def submit_quiz():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    answers = request.form.to_dict()
    score = 0
    total_questions = len(answers)
    
    for q_id, user_answer in answers.items():
        question = Question.query.get(int(q_id))
        if question and user_answer == question.correct_answer:
            score += 1
    
    percentage_score = (score / total_questions) * 100 if total_questions > 0 else 0
    feedback = get_feedback(percentage_score)
    
    quiz_result = QuizResult(user_id=user_id, score=percentage_score)
    db.session.add(quiz_result)
    db.session.commit()
    
    return render_template('quiz_result.html', score=percentage_score, feedback=feedback)

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    if not user:
        return redirect(url_for('login'))

    quiz_results = QuizResult.query.filter_by(user_id=user_id).order_by(QuizResult.date_taken.desc()).all()

    return render_template('profile.html', user=user, quiz_results=quiz_results)

if __name__ == '__main__':
    app.run(debug=True)

# add_difficulty_column.py
import sqlite3
import os

# مسیر فایل دیتابیس
db_path = 'A:/PythonProject/instance/quiz.db'


def add_difficulty_column():
    """افزودن ستون سطح دشواری به جدول سوالات با استفاده از SQLite مستقیم"""

    if not os.path.exists(db_path):
        print(f"خطا: فایل دیتابیس {db_path} یافت نشد!")
        return False

    try:
        # اتصال به دیتابیس
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # بررسی وجود ستون difficulty
        cursor.execute("PRAGMA table_info(question)")
        columns = cursor.fetchall()
        column_names = [column[1] for column in columns]

        if 'difficulty' not in column_names:
            # اضافه کردن ستون difficulty
            cursor.execute("ALTER TABLE question ADD COLUMN difficulty VARCHAR(10) DEFAULT 'متوسط' NOT NULL")
            conn.commit()
            print("ستون 'difficulty' با موفقیت اضافه شد")

            # تنظیم مقدار پیش‌فرض برای همه رکوردهای موجود
            cursor.execute("UPDATE question SET difficulty = 'متوسط'")
            conn.commit()
            print("مقدار پیش‌فرض برای سطح دشواری تنظیم شد")

            print("مهاجرت با موفقیت انجام شد")
        else:
            print("ستون 'difficulty' از قبل وجود دارد")

        # بستن اتصال
        conn.close()
        return True

    except Exception as e:
        print(f"خطا در مهاجرت: {str(e)}")
        if 'conn' in locals() and conn:
            conn.rollback()
            conn.close()
        return False


if __name__ == '__main__':
    add_difficulty_column()
# migrate_attachments.py
from app import app, db, TicketMessage, TicketAttachment
from sqlalchemy import text
import os


def create_attachments_table():
    """ایجاد جدول attachments و اضافه کردن فیلدهای ویرایش به جدول پیام‌ها"""
    with app.app_context():
        try:
            # بررسی وجود ستون های مورد نیاز در جدول ticket_message
            inspector = db.inspect(db.engine)
            message_columns = [column['name'] for column in inspector.get_columns('ticket_message')]

            # اضافه کردن ستون edited اگر وجود ندارد
            if 'edited' not in message_columns:
                db.session.execute(text("ALTER TABLE ticket_message ADD COLUMN edited BOOLEAN DEFAULT FALSE NOT NULL"))
                print("ستون 'edited' با موفقیت اضافه شد")

            # اضافه کردن ستون edited_at اگر وجود ندارد
            if 'edited_at' not in message_columns:
                db.session.execute(text("ALTER TABLE ticket_message ADD COLUMN edited_at DATETIME"))
                print("ستون 'edited_at' با موفقیت اضافه شد")

            # بررسی وجود جدول ticket_attachment
            tables = inspector.get_table_names()
            if 'ticket_attachment' not in tables:
                # ایجاد جدول ticket_attachment
                db.session.execute(text("""
                CREATE TABLE ticket_attachment (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ticket_id INTEGER NOT NULL,
                    message_id INTEGER,
                    filename VARCHAR(255) NOT NULL,
                    file_path VARCHAR(255) NOT NULL,
                    file_type VARCHAR(50) NOT NULL,
                    file_size INTEGER NOT NULL,
                    upload_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (ticket_id) REFERENCES ticket (id),
                    FOREIGN KEY (message_id) REFERENCES ticket_message (id)
                )
                """))
                print("جدول 'ticket_attachment' با موفقیت ایجاد شد")

            # ایجاد دایرکتوری آپلود
            uploads_dir = os.path.join(app.static_folder, 'uploads', 'tickets')
            os.makedirs(uploads_dir, exist_ok=True)
            print(f"دایرکتوری آپلود در مسیر '{uploads_dir}' ایجاد شد")

            db.session.commit()
            print("مهاجرت دیتابیس با موفقیت انجام شد")

            return True
        except Exception as e:
            db.session.rollback()
            print(f"خطا در مهاجرت دیتابیس: {str(e)}")
            return False


if __name__ == '__main__':
    create_attachments_table()
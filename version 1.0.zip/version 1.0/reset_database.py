import os
from app import app, db


def reset_database():
    with app.app_context():
        # مسیر فایل دیتابیس
        db_path = os.path.join(app.instance_path, 'quiz.db')

        # اگر فایل دیتابیس وجود دارد، آن را حذف کنید
        if os.path.exists(db_path):
            os.remove(db_path)
            print(f"فایل دیتابیس قبلی حذف شد: {db_path}")

        # ایجاد همه جداول از نو
        db.create_all()
        print("جداول جدید با موفقیت ایجاد شدند")

        return True


if __name__ == '__main__':
    reset_database()